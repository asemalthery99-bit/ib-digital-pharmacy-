import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure, adminProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { createPaymentIntent, getPaymentIntent } from "./stripe";
import { getDb } from "./db";
import { orders, orderItems, paymentIntents, products, cart, prescriptions, consultations } from "../drizzle/schema";
import { TRPCError } from "@trpc/server";
import { eq } from "drizzle-orm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Products router
  products: router({
    list: publicProcedure.query(async () => {
      return await db.getAllProducts();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getProductById(input.id);
      }),

    getByCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        return await db.getProductsByCategory(input.category);
      }),

    search: publicProcedure
      .input(z.object({ query: z.string() }))
      .query(async ({ input }) => {
        const allProducts = await db.getAllProducts();
        return allProducts.filter(p =>
          p.name.toLowerCase().includes(input.query.toLowerCase()) ||
          p.description?.toLowerCase().includes(input.query.toLowerCase())
        );
      }),

    create: adminProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        price: z.number().positive(),
        category: z.string().min(1),
        stock: z.number().int().min(0),
        image: z.string().optional(),
        requiresPrescription: z.boolean().default(false),
      }))
      .mutation(async ({ input }) => {
        const database = await getDb();
        if (!database) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
        const result = await database.insert(products).values({
          ...input,
          price: input.price.toString() as any,
        });
        return { id: (result as any).insertId };
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        price: z.number().positive().optional(),
        category: z.string().optional(),
        stock: z.number().int().min(0).optional(),
        image: z.string().optional(),
        requiresPrescription: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const database = await getDb();
        if (!database) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
        const { id, ...updateData } = input;
        const finalUpdateData: any = { ...updateData };
        if (updateData.price !== undefined) {
          finalUpdateData.price = updateData.price.toString();
        }
        await database.update(products)
          .set(finalUpdateData)
          .where(eq(products.id, id));
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const database = await getDb();
        if (!database) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
        await database.delete(products).where(eq(products.id, input.id));
        return { success: true };
      }),
  }),

  // Orders router
  orders: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getOrdersByUserId(ctx.user.id);
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const order = await db.getOrderById(input.id);
        if (!order || order.userId !== ctx.user.id) {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        const items = await db.getOrderItemsByOrderId(input.id);
        return { ...order, items };
      }),

    create: protectedProcedure
      .input(z.object({
        shippingAddress: z.string(),
        notes: z.string().optional(),
        items: z.array(z.object({
          productId: z.number(),
          quantity: z.number().min(1),
        })),
      }))
      .mutation(async ({ input, ctx }) => {
        const database = await getDb();
        if (!database) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        // Calculate total amount
        let totalAmount = 0;
        const productIds = input.items.map(item => item.productId);
        const productsData = await Promise.all(
          productIds.map(id => db.getProductById(id))
        );

        for (let i = 0; i < input.items.length; i++) {
          const product = productsData[i];
          if (!product) throw new TRPCError({ code: 'NOT_FOUND' });
          totalAmount += Number(product.price) * input.items[i].quantity;
        }

        // Create order
        const result = await database.insert(orders).values({
          userId: ctx.user.id,
          totalAmount: totalAmount.toString() as any,
          shippingAddress: input.shippingAddress,
          notes: input.notes,
          status: 'pending',
        });

        const orderId = (result as any).insertId;

        // Create order items
        for (let i = 0; i < input.items.length; i++) {
          const item = input.items[i];
          const product = productsData[i];
          if (product) {
            await database.insert(orderItems).values({
              orderId: Number(orderId),
              productId: item.productId,
              quantity: item.quantity,
              price: product.price.toString() as any,
            });
          }
        }

        return { orderId: Number(orderId), totalAmount };
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        status: z.enum(['pending', 'processing', 'ready', 'shipped', 'delivered', 'cancelled']),
      }))
      .mutation(async ({ input, ctx }) => {
        const database = await getDb();
        if (!database) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const order = await db.getOrderById(input.orderId);
        if (!order) throw new TRPCError({ code: 'NOT_FOUND' });

        // Only admin or order owner can update status
        if (ctx.user.role !== 'admin' && order.userId !== ctx.user.id) {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }

        await database.update(orders)
          .set({ status: input.status })
          .where(eq(orders.id, input.orderId));

        return { success: true };
      }),
  }),

  // Payment router
  payment: router({
    createIntent: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        amount: z.number().positive(),
      }))
      .mutation(async ({ input, ctx }) => {
        const order = await db.getOrderById(input.orderId);
        if (!order || order.userId !== ctx.user.id) {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }

        try {
          const paymentIntent = await createPaymentIntent(
            input.amount,
            input.orderId,
            ctx.user.email || undefined
          );

          const database = await getDb();
          if (!database) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

          // Save payment intent to database
          await database.insert(paymentIntents).values({
            orderId: input.orderId,
            stripePaymentIntentId: paymentIntent.id,
            amount: input.amount.toString() as any,
            status: paymentIntent.status as any,
            clientSecret: paymentIntent.client_secret,
          });

          return {
            clientSecret: paymentIntent.client_secret,
            paymentIntentId: paymentIntent.id,
          };
        } catch (error) {
          console.error('[Payment] Error creating payment intent:', error);
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Failed to create payment intent',
          });
        }
      }),

    getStatus: protectedProcedure
      .input(z.object({ paymentIntentId: z.string() }))
      .query(async ({ input }) => {
        try {
          const paymentIntent = await getPaymentIntent(input.paymentIntentId);
          return {
            status: paymentIntent.status,
            amount: paymentIntent.amount,
          };
        } catch (error) {
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Failed to get payment status',
          });
        }
      }),
  }),

  // Cart router
  cart: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const userCart = await db.getCartByUserId(ctx.user.id);
      if (!userCart) return { items: [] };
      try {
        return { items: userCart.items ? JSON.parse(userCart.items) : [] };
      } catch {
        return { items: [] };
      }
    }),

    update: protectedProcedure
      .input(z.object({
        items: z.array(z.object({
          productId: z.number(),
          quantity: z.number().min(0),
        })),
      }))
      .mutation(async ({ input, ctx }) => {
        const database = await getDb();
        if (!database) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const existingCart = await db.getCartByUserId(ctx.user.id);
        const cartData = {
          userId: ctx.user.id,
          items: JSON.stringify(input.items),
        };

        if (existingCart) {
          await database.update(cart)
            .set(cartData)
            .where(eq(cart.userId, ctx.user.id));
        } else {
          await database.insert(cart).values(cartData);
        }

        return { success: true };
      }),
  }),

  // Prescriptions router
  prescriptions: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getPrescriptionsByUserId(ctx.user.id);
    }),

    upload: protectedProcedure
      .input(z.object({
        doctorName: z.string(),
        prescriptionDate: z.date(),
        expiryDate: z.date().optional(),
        fileUrl: z.string(),
        medicines: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const database = await getDb();
        if (!database) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const result = await database.insert(prescriptions).values({
          userId: ctx.user.id,
          doctorName: input.doctorName,
          prescriptionDate: input.prescriptionDate,
          expiryDate: input.expiryDate,
          fileUrl: input.fileUrl,
          medicines: input.medicines,
          notes: input.notes,
          verified: false,
        });

        return { prescriptionId: (result as any).insertId };
      }),
  }),

  // Consultations router
  consultations: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getConsultationsByUserId(ctx.user.id);
    }),

    create: protectedProcedure
      .input(z.object({
        question: z.string(),
        category: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const database = await getDb();
        if (!database) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const result = await database.insert(consultations).values({
          userId: ctx.user.id,
          question: input.question,
          category: input.category,
          resolved: false,
        });

        return { consultationId: (result as any).insertId };
      }),
  }),
});

export type AppRouter = typeof appRouter;
