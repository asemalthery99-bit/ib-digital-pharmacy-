import { z } from "zod";
import { notifyOwner } from "./notification";
import { adminProcedure, publicProcedure, router, protectedProcedure } from "./trpc";
import { storagePut } from "../storage";

export const systemRouter = router({
  health: publicProcedure
    .input(
      z.object({
        timestamp: z.number().min(0, "timestamp cannot be negative"),
      })
    )
    .query(() => ({
      ok: true,
    })),

  notifyOwner: adminProcedure
    .input(
      z.object({
        title: z.string().min(1, "title is required"),
        content: z.string().min(1, "content is required"),
      })
    )
    .mutation(async ({ input }) => {
      const delivered = await notifyOwner(input);
      return {
        success: delivered,
      } as const;
    }),

  upload: protectedProcedure
    .input(z.object({
      fileName: z.string(),
      fileType: z.string(),
      base64Data: z.string(),
    }))
    .mutation(async ({ input }) => {
      const buffer = Buffer.from(input.base64Data, 'base64');
      const result = await storagePut(
        `uploads/${Date.now()}-${input.fileName}`,
        buffer,
        input.fileType
      );
      return result;
    }),
});
