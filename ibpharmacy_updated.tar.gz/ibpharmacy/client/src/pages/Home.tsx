import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLocation } from "wouter";
import { 
  Search, 
  ShoppingCart, 
  Stethoscope, 
  Truck, 
  ShieldCheck, 
  Clock,
  ArrowRight,
  PlusCircle
} from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Navigation Bar */}
      <nav className="border-b sticky top-0 bg-white/80 backdrop-blur-md z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/")}>
            <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">إب</div>
            <span className="text-xl font-bold text-gray-900">صيدلية إب الرقمية</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-600">
            <button onClick={() => navigate("/products")} className="hover:text-green-600 transition-colors">الأدوية</button>
            <button onClick={() => navigate("/consultations")} className="hover:text-green-600 transition-colors">الاستشارات</button>
            <button onClick={() => navigate("/orders")} className="hover:text-green-600 transition-colors">طلباتي</button>
            {user?.role === 'admin' && (
              <button onClick={() => navigate("/admin")} className="text-blue-600 hover:text-blue-700 font-bold">لوحة التحكم</button>
            )}
          </div>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/cart")}>
              <ShoppingCart className="w-5 h-5" />
            </Button>
            {isAuthenticated ? (
              <div className="flex items-center gap-2">
                <span className="text-sm hidden sm:inline">{user?.name}</span>
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-700 text-xs font-bold">
                  {user?.name?.charAt(0)}
                </div>
              </div>
            ) : (
              <Button onClick={() => window.location.href = "/api/auth/login"} className="bg-green-600 hover:bg-green-700">
                تسجيل الدخول
              </Button>
            )}
          </div>
        </div>
      </nav>

      <main>
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden bg-gradient-to-br from-green-50 via-white to-blue-50">
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl">
              <Badge className="mb-4 bg-green-100 text-green-700 hover:bg-green-100 border-none px-3 py-1">صيدليتك الموثوقة في جيبك</Badge>
              <h1 className="text-5xl md:text-6xl font-extrabold text-gray-900 mb-6 leading-tight">
                رعاية صحية <span className="text-green-600">ذكية</span> <br />
                تصلك أينما كنت
              </h1>
              <p className="text-xl text-gray-600 mb-10 leading-relaxed">
                احصل على أدويتك، استشاراتك الطبية، وإدارة وصفاتك بكل سهولة وأمان من خلال منصة إب الرقمية المتكاملة.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button size="lg" onClick={() => navigate("/products")} className="bg-green-600 hover:bg-green-700 px-8 h-14 text-lg">
                  تسوق الآن
                  <ArrowRight className="mr-2 w-5 h-5" />
                </Button>
                <Button size="lg" variant="outline" onClick={() => navigate("/consultations")} className="px-8 h-14 text-lg border-2">
                  استشارة صيدلانية
                </Button>
              </div>
            </div>
          </div>
          
          {/* Decorative Elements */}
          <div className="absolute top-1/2 -right-20 -translate-y-1/2 w-[500px] h-[500px] bg-green-200/20 rounded-full blur-3xl -z-10"></div>
          <div className="absolute bottom-0 left-1/4 w-[300px] h-[300px] bg-blue-200/20 rounded-full blur-3xl -z-10"></div>
        </section>

        {/* Features Grid */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">لماذا تختار صيدلية إب الرقمية؟</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">نحن نجمع بين التكنولوجيا والخبرة الطبية لنقدم لك أفضل تجربة رعاية صحية ممكنة.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <FeatureCard 
                icon={<ShieldCheck className="w-8 h-8 text-green-600" />}
                title="أدوية أصلية 100%"
                description="جميع منتجاتنا تأتي من مصادر موثوقة ومرخصة لضمان سلامتك."
              />
              <FeatureCard 
                icon={<Truck className="w-8 h-8 text-blue-600" />}
                title="توصيل سريع"
                description="نصل إليك في أسرع وقت ممكن مع الحفاظ على جودة تخزين الأدوية."
              />
              <FeatureCard 
                icon={<Stethoscope className="w-8 h-8 text-purple-600" />}
                title="استشارات متخصصة"
                description="فريق من الصيادلة المحترفين جاهز للرد على استفساراتك على مدار الساعة."
              />
            </div>
          </div>
        </section>

        {/* Quick Actions */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card className="bg-gradient-to-r from-green-600 to-green-700 text-white border-none overflow-hidden relative group">
                <CardContent className="p-10 relative z-10">
                  <h3 className="text-2xl font-bold mb-4">هل لديك وصفة طبية؟</h3>
                  <p className="text-green-50 mb-8 max-w-md">ارفع صورة وصفتك الطبية الآن وسيقوم فريقنا بتجهيزها لك وتوصيلها فوراً.</p>
                  <Button variant="secondary" size="lg" onClick={() => navigate("/orders")} className="font-bold">
                    <PlusCircle className="ml-2 w-5 h-5" />
                    رفع الوصفة الطبية
                  </Button>
                </CardContent>
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-20 -mt-20 blur-2xl group-hover:scale-110 transition-transform duration-500"></div>
              </Card>

              <Card className="bg-gradient-to-r from-blue-600 to-blue-700 text-white border-none overflow-hidden relative group">
                <CardContent className="p-10 relative z-10">
                  <h3 className="text-2xl font-bold mb-4">تتبع طلبك بسهولة</h3>
                  <p className="text-blue-50 mb-8 max-w-md">ابقَ على اطلاع دائم بحالة طلبك من لحظة التجهيز وحتى وصوله إلى باب منزلك.</p>
                  <Button variant="secondary" size="lg" onClick={() => navigate("/orders")} className="font-bold">
                    <Clock className="ml-2 w-5 h-5" />
                    تتبع الطلبات
                  </Button>
                </CardContent>
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-20 -mt-20 blur-2xl group-hover:scale-110 transition-transform duration-500"></div>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-gray-400 py-12 border-t border-gray-800">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 bg-green-600 rounded flex items-center justify-center text-white font-bold">إب</div>
                <span className="text-xl font-bold text-white">صيدلية إب الرقمية</span>
              </div>
              <p className="max-w-sm leading-relaxed">
                نحن ملتزمون بتقديم أفضل الخدمات الصحية الرقمية في المنطقة، مع التركيز على الجودة، السرعة، والخصوصية.
              </p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-6">روابط سريعة</h4>
              <ul className="space-y-4 text-sm">
                <li><button onClick={() => navigate("/products")} className="hover:text-green-500 transition-colors">كتالوج الأدوية</button></li>
                <li><button onClick={() => navigate("/consultations")} className="hover:text-green-500 transition-colors">طلب استشارة</button></li>
                <li><button onClick={() => navigate("/orders")} className="hover:text-green-500 transition-colors">تتبع الطلبات</button></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-6">تواصل معنا</h4>
              <ul className="space-y-4 text-sm">
                <li>البريد: info@ibpharmacy.com</li>
                <li>الهاتف: +967 123 456 789</li>
                <li>العنوان: إب، الجمهورية اليمنية</li>
              </ul>
            </div>
          </div>
          <div className="pt-8 border-t border-gray-800 text-center text-xs">
            <p>© 2026 صيدلية إب الرقمية. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <Card className="border-none shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="p-8">
        <div className="mb-6">{icon}</div>
        <h3 className="text-xl font-bold text-gray-900 mb-3">{title}</h3>
        <p className="text-gray-600 leading-relaxed">{description}</p>
      </CardContent>
    </Card>
  );
}

function Badge({ children, className }: { children: React.ReactNode, className?: string }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 ${className}`}>
      {children}
    </span>
  );
}
