import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, Trash2, ShoppingCart, ArrowLeft, Minus, Plus, ShieldCheck, Truck } from "lucide-react";
import { toast } from "sonner";

interface CartItem {
  productId: number;
  quantity: number;
}

export default function Cart() {
  const [, navigate] = useLocation();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const cartQuery = trpc.cart.get.useQuery();
  const cartMutation = trpc.cart.update.useMutation();
  const productsQuery = trpc.products.list.useQuery();
  const createOrderMutation = trpc.orders.create.useMutation();

  // Load cart items
  useEffect(() => {
    if (cartQuery.data?.items) {
      setCartItems(cartQuery.data.items as CartItem[]);
    }
    setIsLoading(false);
  }, [cartQuery.data]);

  // Calculate totals
  const subtotal = cartItems.reduce((sum, item) => {
    const product = productsQuery.data?.find(p => p.id === item.productId);
    return sum + (product ? Number(product.price) * item.quantity : 0);
  }, 0);

  const tax = subtotal * 0.05; // 5% tax
  const total = subtotal + tax;

  const handleUpdateQuantity = async (productId: number, newQuantity: number) => {
    if (newQuantity < 0) return;

    const newItems = newQuantity === 0
      ? cartItems.filter(item => item.productId !== productId)
      : cartItems.map(item =>
          item.productId === productId ? { ...item, quantity: newQuantity } : item
        );

    setCartItems(newItems);
    await cartMutation.mutateAsync({ items: newItems });
    cartQuery.refetch();
  };

  const handleRemoveItem = async (productId: number) => {
    const newItems = cartItems.filter(item => item.productId !== productId);
    setCartItems(newItems);
    await cartMutation.mutateAsync({ items: newItems });
    cartQuery.refetch();
    toast.success("تم حذف المنتج من السلة");
  };

  const handleCheckout = async () => {
    if (cartItems.length === 0) {
      toast.error("السلة فارغة");
      return;
    }

    try {
      const order = await createOrderMutation.mutateAsync({
        shippingAddress: "العنوان الافتراضي - سيتم تحديثه في صفحة الدفع",
        items: cartItems,
      });

      toast.success("تم إنشاء الطلب بنجاح");
      setCartItems([]);
      await cartMutation.mutateAsync({ items: [] });
      cartQuery.refetch();

      // Navigate to payment
      navigate(`/payment/${order.orderId}`);
    } catch (error: any) {
      toast.error(error.message || "فشل إنشاء الطلب");
    }
  };

  if (isLoading || productsQuery.isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white">
        <Loader2 className="w-10 h-10 animate-spin text-green-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <nav className="border-b sticky top-0 bg-white/80 backdrop-blur-md z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/products")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/")}>
              <div className="w-8 h-8 bg-green-600 rounded flex items-center justify-center text-white font-bold">إب</div>
              <span className="text-lg font-bold text-gray-900">سلة التسوق</span>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-12">
        {cartItems.length === 0 ? (
          <div className="max-w-md mx-auto text-center py-20">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-8">
              <ShoppingCart className="w-12 h-12 text-gray-300" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">سلتك فارغة حالياً</h2>
            <p className="text-gray-500 mb-10">ابدأ بإضافة بعض الأدوية والمنتجات الصحية إلى سلتك.</p>
            <Button
              onClick={() => navigate("/products")}
              className="bg-green-600 hover:bg-green-700 px-10 h-12 text-lg font-bold"
            >
              تصفح الأدوية
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Cart Items List */}
            <div className="lg:col-span-2 space-y-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-900">المنتجات ({cartItems.length})</h2>
                <Button variant="ghost" size="sm" onClick={() => {
                  setCartItems([]);
                  cartMutation.mutate({ items: [] });
                }} className="text-red-500 hover:text-red-600 hover:bg-red-50">
                  مسح السلة
                </Button>
              </div>

              {cartItems.map(item => {
                const product = productsQuery.data?.find(p => p.id === item.productId);
                if (!product) return null;

                return (
                  <Card key={item.productId} className="border-none shadow-sm overflow-hidden group">
                    <CardContent className="p-6">
                      <div className="flex gap-6">
                        {/* Product Image */}
                        <div className="w-24 h-24 bg-gray-50 rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden">
                          {product.image ? (
                            <img
                              src={product.image}
                              alt={product.name}
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                            />
                          ) : (
                            <span className="text-3xl">💊</span>
                          )}
                        </div>

                        {/* Product Details */}
                        <div className="flex-1 flex flex-col justify-between">
                          <div>
                            <div className="flex justify-between items-start">
                              <h3 className="font-bold text-lg text-gray-900 mb-1">{product.name}</h3>
                              <button
                                onClick={() => handleRemoveItem(item.productId)}
                                className="text-gray-400 hover:text-red-500 transition-colors"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                            <p className="text-xs text-green-600 font-bold uppercase tracking-wider mb-2">{product.category}</p>
                          </div>

                          <div className="flex items-center justify-between mt-4">
                            <div className="flex items-center gap-3 bg-gray-50 rounded-lg p-1 border">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleUpdateQuantity(item.productId, item.quantity - 1)}
                                className="h-8 w-8 hover:bg-white hover:shadow-sm"
                              >
                                <Minus className="w-3 h-3" />
                              </Button>
                              <span className="w-8 text-center font-bold text-sm">{item.quantity}</span>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleUpdateQuantity(item.productId, item.quantity + 1)}
                                className="h-8 w-8 hover:bg-white hover:shadow-sm"
                              >
                                <Plus className="w-3 h-3" />
                              </Button>
                            </div>
                            <p className="font-bold text-xl text-gray-900">
                              ${(Number(product.price) * item.quantity).toFixed(2)}
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Order Summary Sidebar */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24 border-none shadow-lg bg-white">
                <CardContent className="p-8">
                  <h3 className="text-xl font-bold text-gray-900 mb-8">ملخص الطلب</h3>
                  
                  <div className="space-y-4 mb-8">
                    <div className="flex justify-between text-gray-500">
                      <span>المجموع الفرعي</span>
                      <span className="font-bold text-gray-900">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-gray-500">
                      <span>الضريبة (5%)</span>
                      <span className="font-bold text-gray-900">${tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-gray-500">
                      <span>رسوم التوصيل</span>
                      <span className="font-bold text-green-600">مجاني</span>
                    </div>
                    <div className="pt-4 border-t flex justify-between items-center">
                      <span className="text-lg font-bold text-gray-900">الإجمالي</span>
                      <span className="text-2xl font-extrabold text-green-600">${total.toFixed(2)}</span>
                    </div>
                  </div>

                  <Button
                    onClick={handleCheckout}
                    disabled={createOrderMutation.isPending}
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-bold h-14 text-lg shadow-lg shadow-green-100 mb-6"
                  >
                    {createOrderMutation.isPending ? (
                      <Loader2 className="w-6 h-6 animate-spin" />
                    ) : (
                      "إتمام الطلب"
                    )}
                  </Button>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <ShieldCheck className="w-4 h-4 text-green-600" />
                      <span>دفع آمن ومشفر 100%</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <Truck className="w-4 h-4 text-blue-600" />
                      <span>توصيل سريع خلال 24 ساعة</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
