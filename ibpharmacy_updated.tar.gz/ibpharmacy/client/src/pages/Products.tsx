import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Search, ShoppingCart, Heart, Filter, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function Products() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [wishlist, setWishlist] = useState<Set<number>>(new Set());

  const productsQuery = trpc.products.list.useQuery();
  const cartMutation = trpc.cart.update.useMutation();
  const cartQuery = trpc.cart.get.useQuery();

  // Get unique categories
  const categories = useMemo(() => {
    if (!productsQuery.data) return [];
    const cats = new Set(productsQuery.data.map(p => p.category));
    return Array.from(cats).sort();
  }, [productsQuery.data]);

  // Filter products
  const filteredProducts = useMemo(() => {
    if (!productsQuery.data) return [];

    return productsQuery.data.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === "all" || product.category === selectedCategory;
      const price = Number(product.price);
      const matchesPrice = price >= priceRange[0] && price <= priceRange[1];

      return matchesSearch && matchesCategory && matchesPrice;
    });
  }, [productsQuery.data, searchQuery, selectedCategory, priceRange]);

  const handleAddToCart = async (productId: number, quantity: number = 1) => {
    try {
      const currentCart = cartQuery.data;
      const items = (currentCart?.items as any[]) || [];

      const existingItem = items.find((item: any) => item.productId === productId);
      if (existingItem) {
        existingItem.quantity += quantity;
      } else {
        items.push({ productId, quantity });
      }

      await cartMutation.mutateAsync({ items });
      cartQuery.refetch();
      toast.success("تمت إضافة المنتج إلى السلة");
    } catch (error) {
      toast.error("فشل إضافة المنتج إلى السلة");
    }
  };

  const toggleWishlist = (productId: number) => {
    const newWishlist = new Set(wishlist);
    if (newWishlist.has(productId)) {
      newWishlist.delete(productId);
    } else {
      newWishlist.add(productId);
    }
    setWishlist(newWishlist);
  };

  if (productsQuery.isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-green-600 mx-auto mb-4" />
          <p className="text-gray-500 font-medium">جاري تحميل الأدوية...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <nav className="border-b sticky top-0 bg-white/80 backdrop-blur-md z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/")}>
              <div className="w-8 h-8 bg-green-600 rounded flex items-center justify-center text-white font-bold">إب</div>
              <span className="text-lg font-bold text-gray-900 hidden sm:inline">صيدلية إب الرقمية</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="relative hidden md:block w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="ابحث عن دواء..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-gray-100 border-none h-10"
              />
            </div>
            <Button variant="ghost" size="icon" onClick={() => navigate("/cart")} className="relative">
              <ShoppingCart className="w-5 h-5" />
              {cartQuery.data?.items && (cartQuery.data.items as any[]).length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {(cartQuery.data.items as any[]).length}
                </span>
              )}
            </Button>
          </div>
        </div>
      </nav>

      {/* Header */}
      <div className="bg-white border-b py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">كتالوج الأدوية</h1>
          <p className="text-gray-500">تصفح مجموعتنا الواسعة من الأدوية والمنتجات الصحية الموثوقة.</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar - Filters */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24 border-none shadow-sm">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-green-600" />
                  <CardTitle className="text-lg">الفلاتر</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Mobile Search */}
                <div className="md:hidden">
                  <label className="text-sm font-medium mb-2 block">البحث</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="ابحث عن منتج..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Category */}
                <div>
                  <label className="text-sm font-medium mb-2 block">الفئة</label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="bg-gray-50 border-none">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع الفئات</SelectItem>
                      {categories.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Price Range */}
                <div>
                  <label className="text-sm font-medium mb-2 block">نطاق السعر</label>
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <span className="text-[10px] text-gray-400 uppercase font-bold">من</span>
                        <Input
                          type="number"
                          value={priceRange[0]}
                          onChange={(e) => setPriceRange([Number(e.target.value), priceRange[1]])}
                          className="bg-gray-50 border-none h-9"
                        />
                      </div>
                      <div className="flex-1">
                        <span className="text-[10px] text-gray-400 uppercase font-bold">إلى</span>
                        <Input
                          type="number"
                          value={priceRange[1]}
                          onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
                          className="bg-gray-50 border-none h-9"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <Button
                  variant="outline"
                  className="w-full border-2"
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory("all");
                    setPriceRange([0, 10000]);
                  }}
                >
                  إعادة تعيين
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content - Products Grid */}
          <div className="lg:col-span-3">
            <div className="flex items-center justify-between mb-6">
              <p className="text-sm text-gray-500">
                عرض <span className="font-bold text-gray-900">{filteredProducts.length}</span> منتج
              </p>
            </div>

            {filteredProducts.length === 0 ? (
              <Card className="text-center py-20 border-none shadow-sm">
                <CardContent>
                  <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Search className="w-10 h-10 text-gray-300" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">لا توجد نتائج</h3>
                  <p className="text-gray-500 mb-8">لم نجد أي منتجات تطابق معايير البحث الخاصة بك.</p>
                  <Button
                    variant="default"
                    className="bg-green-600 hover:bg-green-700"
                    onClick={() => {
                      setSearchQuery("");
                      setSelectedCategory("all");
                      setPriceRange([0, 10000]);
                    }}
                  >
                    عرض جميع المنتجات
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map(product => (
                  <Card
                    key={product.id}
                    className="group border-none shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col bg-white"
                  >
                    {/* Product Image */}
                    <div className="aspect-square bg-gray-50 flex items-center justify-center relative overflow-hidden">
                      {product.image ? (
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                      ) : (
                        <div className="text-center">
                          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                            <span className="text-2xl">💊</span>
                          </div>
                          <p className="text-gray-400 text-xs">لا توجد صورة</p>
                        </div>
                      )}

                      {/* Badges */}
                      <div className="absolute top-3 right-3 flex flex-col gap-2">
                        <button
                          onClick={() => toggleWishlist(product.id)}
                          className="bg-white/90 backdrop-blur-sm rounded-full p-2 shadow-sm hover:bg-red-50 transition-colors"
                        >
                          <Heart
                            className={`w-4 h-4 ${
                              wishlist.has(product.id)
                                ? "fill-red-500 text-red-500"
                                : "text-gray-400"
                            }`}
                          />
                        </button>
                      </div>

                      {product.requiresPrescription && (
                        <div className="absolute bottom-3 left-3 bg-red-500/90 backdrop-blur-sm text-white px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider">
                          يتطلب وصفة
                        </div>
                      )}
                    </div>

                    {/* Product Info */}
                    <CardHeader className="p-5 pb-2">
                      <div className="flex justify-between items-start mb-1">
                        <span className="text-[10px] font-bold text-green-600 uppercase tracking-widest">
                          {product.category}
                        </span>
                        <span className="text-lg font-bold text-gray-900">
                          ${Number(product.price).toFixed(2)}
                        </span>
                      </div>
                      <CardTitle className="text-base font-bold text-gray-900 line-clamp-1 group-hover:text-green-600 transition-colors">
                        {product.name}
                      </CardTitle>
                      <CardDescription className="text-xs text-gray-500 line-clamp-2 mt-2 leading-relaxed">
                        {product.description}
                      </CardDescription>
                    </CardHeader>

                    {/* Product Footer */}
                    <CardContent className="p-5 pt-4 mt-auto border-t border-gray-50">
                      <div className="flex items-center justify-between gap-4">
                        <Button
                          onClick={() => handleAddToCart(product.id)}
                          disabled={product.stock === 0}
                          className="flex-1 bg-green-600 hover:bg-green-700 h-10 text-xs font-bold"
                        >
                          <ShoppingCart className="w-3 h-3 ml-2" />
                          أضف للسلة
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => navigate(`/product/${product.id}`)}
                          className="h-10 w-10 border-2"
                        >
                          <ArrowLeft className="w-4 h-4" />
                        </Button>
                      </div>
                      {product.stock <= 5 && product.stock > 0 && (
                        <p className="text-[10px] text-orange-600 font-bold mt-3 text-center">
                          تبقى {product.stock} قطع فقط في المخزون!
                        </p>
                      )}
                      {product.stock === 0 && (
                        <p className="text-[10px] text-red-600 font-bold mt-3 text-center">
                          نفذت الكمية
                        </p>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
