import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Loader2, Package, ShoppingCart, Users, TrendingUp, Edit2, Trash2, Plus, Upload, X } from "lucide-react";
import { toast } from "sonner";
import { fileToBase64 } from "@/hooks/useFileUpload";

export default function AdminDashboard() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();

  // Check if user is admin
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-green-600" />
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-red-600 font-bold mb-4">❌ لا توجد صلاحيات</p>
            <p className="text-gray-600 mb-6">أنت لا تملك صلاحيات الوصول إلى لوحة التحكم الإدارية</p>
            <Button onClick={() => navigate("/")} className="bg-green-600">
              العودة للرئيسية
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold mb-2">لوحة التحكم الإدارية</h1>
          <p className="text-green-100">مرحباً، {user.name}</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="إجمالي المنتجات"
            value="24"
            icon={<Package className="w-6 h-6" />}
            color="bg-blue-100 text-blue-600"
          />
          <StatCard
            title="الطلبات اليوم"
            value="12"
            icon={<ShoppingCart className="w-6 h-6" />}
            color="bg-green-100 text-green-600"
          />
          <StatCard
            title="المستخدمون"
            value="156"
            icon={<Users className="w-6 h-6" />}
            color="bg-purple-100 text-purple-600"
          />
          <StatCard
            title="المبيعات الشهرية"
            value="$4,250"
            icon={<TrendingUp className="w-6 h-6" />}
            color="bg-orange-100 text-orange-600"
          />
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="products" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="products">المنتجات</TabsTrigger>
            <TabsTrigger value="orders">الطلبات</TabsTrigger>
            <TabsTrigger value="users">المستخدمون</TabsTrigger>
            <TabsTrigger value="settings">الإعدادات</TabsTrigger>
          </TabsList>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-6">
            <ProductsManager />
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders" className="space-y-6">
            <h2 className="text-2xl font-bold">إدارة الطلبات</h2>
            <OrdersTable />
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <h2 className="text-2xl font-bold">إدارة المستخدمين</h2>
            <UsersTable />
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <h2 className="text-2xl font-bold">الإعدادات</h2>
            <SettingsPanel />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Statistics Card Component
function StatCard({
  title,
  value,
  icon,
  color,
}: {
  title: string;
  value: string;
  icon: React.ReactNode;
  color: string;
}) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-600 text-sm mb-1">{title}</p>
            <p className="text-3xl font-bold">{value}</p>
          </div>
          <div className={`p-3 rounded-lg ${color}`}>{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}

// Products Manager Component
function ProductsManager() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [isUploading, setIsUploading] = useState(false);

  const productsQuery = trpc.products.list.useQuery();
  const createMutation = trpc.products.create.useMutation();
  const updateMutation = trpc.products.update.useMutation();
  const deleteMutation = trpc.products.delete.useMutation();
  const uploadMutation = trpc.system.upload.useMutation();

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: 0,
    category: "",
    stock: 0,
    image: "",
    requiresPrescription: false,
  });

  const handleOpenDialog = (product: any = null) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        description: product.description || "",
        price: Number(product.price),
        category: product.category,
        stock: product.stock,
        image: product.image || "",
        requiresPrescription: product.requiresPrescription,
      });
    } else {
      setEditingProduct(null);
      setFormData({
        name: "",
        description: "",
        price: 0,
        category: "",
        stock: 0,
        image: "",
        requiresPrescription: false,
      });
    }
    setIsDialogOpen(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const base64 = await fileToBase64(file);
      const result = await uploadMutation.mutateAsync({
        fileName: file.name,
        fileType: file.type,
        base64Data: base64,
      });
      setFormData({ ...formData, image: result.url });
      toast.success("تم رفع الصورة بنجاح");
    } catch (error) {
      toast.error("فشل رفع الصورة");
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = async () => {
    try {
      if (editingProduct) {
        await updateMutation.mutateAsync({
          id: editingProduct.id,
          ...formData,
        });
        toast.success("تم تحديث المنتج بنجاح");
      } else {
        await createMutation.mutateAsync(formData);
        toast.success("تم إضافة المنتج بنجاح");
      }
      setIsDialogOpen(false);
      productsQuery.refetch();
    } catch (error) {
      toast.error("فشل حفظ المنتج");
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف هذا المنتج؟")) return;
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("تم حذف المنتج");
      productsQuery.refetch();
    } catch (error) {
      toast.error("فشل حذف المنتج");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">إدارة المنتجات</h2>
        <Button onClick={() => handleOpenDialog()} className="bg-gradient-to-r from-green-600 to-green-700">
          <Plus className="w-4 h-4 mr-2" />
          إضافة منتج جديد
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قائمة المنتجات</CardTitle>
          <CardDescription>{productsQuery.data?.length || 0} منتج</CardDescription>
        </CardHeader>
        <CardContent>
          {productsQuery.isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-green-600" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-right py-3 px-4">الصورة</th>
                    <th className="text-right py-3 px-4">المنتج</th>
                    <th className="text-right py-3 px-4">الفئة</th>
                    <th className="text-right py-3 px-4">السعر</th>
                    <th className="text-right py-3 px-4">المخزون</th>
                    <th className="text-right py-3 px-4">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {productsQuery.data?.map((product: any) => (
                    <tr key={product.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4">
                        {product.image ? (
                          <img src={product.image} alt={product.name} className="w-10 h-10 object-cover rounded" />
                        ) : (
                          <div className="w-10 h-10 bg-gray-100 rounded flex items-center justify-center text-xs">💊</div>
                        )}
                      </td>
                      <td className="py-3 px-4 font-medium">{product.name}</td>
                      <td className="py-3 px-4">{product.category}</td>
                      <td className="py-3 px-4">${Number(product.price).toFixed(2)}</td>
                      <td className="py-3 px-4">
                        <Badge variant={product.stock > 0 ? "default" : "destructive"}>
                          {product.stock}
                        </Badge>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={() => handleOpenDialog(product)}>
                            <Edit2 className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="outline" className="text-red-600" onClick={() => handleDelete(product.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingProduct ? "تعديل منتج" : "إضافة منتج جديد"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">اسم المنتج</label>
                <Input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
              </div>
              <div>
                <label className="text-sm font-medium">الفئة</label>
                <Input value={formData.category} onChange={(e) => setFormData({ ...formData, category: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-sm font-medium">السعر</label>
                  <Input type="number" value={formData.price} onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })} />
                </div>
                <div>
                  <label className="text-sm font-medium">المخزون</label>
                  <Input type="number" value={formData.stock} onChange={(e) => setFormData({ ...formData, stock: Number(e.target.value) })} />
                </div>
              </div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <Checkbox id="prescription" checked={formData.requiresPrescription} onCheckedChange={(checked) => setFormData({ ...formData, requiresPrescription: !!checked })} />
                <label htmlFor="prescription" className="text-sm font-medium">يتطلب وصفة طبية</label>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">الوصف</label>
                <Textarea value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} rows={4} />
              </div>
              <div>
                <label className="text-sm font-medium">صورة المنتج</label>
                <div className="mt-2 flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-4 hover:bg-gray-50 transition-colors relative">
                  {formData.image ? (
                    <div className="relative w-full aspect-video">
                      <img src={formData.image} alt="Preview" className="w-full h-full object-contain rounded" />
                      <button onClick={() => setFormData({ ...formData, image: "" })} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-lg">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="text-center">
                      {isUploading ? (
                        <Loader2 className="w-8 h-8 animate-spin text-green-600 mx-auto" />
                      ) : (
                        <>
                          <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                          <p className="text-xs text-gray-500">انقر لرفع صورة (S3)</p>
                        </>
                      )}
                      <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleImageUpload} accept="image/*" disabled={isUploading} />
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>إلغاء</Button>
            <Button onClick={handleSubmit} className="bg-green-600" disabled={isUploading}>
              {editingProduct ? "تحديث" : "إضافة"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Orders Table Component
function OrdersTable() {
  const ordersQuery = trpc.orders.list.useQuery();

  if (ordersQuery.isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="w-6 h-6 animate-spin text-green-600" />
      </div>
    );
  }

  const orders = ordersQuery.data || [];

  return (
    <Card>
      <CardHeader>
        <CardTitle>الطلبات الأخيرة</CardTitle>
        <CardDescription>{orders.length} طلب</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b">
              <tr>
                <th className="text-right py-3 px-4">رقم الطلب</th>
                <th className="text-right py-3 px-4">الحالة</th>
                <th className="text-right py-3 px-4">المبلغ</th>
                <th className="text-right py-3 px-4">التاريخ</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(order => (
                <tr key={order.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium">#{order.id}</td>
                  <td className="py-3 px-4">
                    <Badge className="bg-blue-100 text-blue-800">{order.status}</Badge>
                  </td>
                  <td className="py-3 px-4">${Number(order.totalAmount).toFixed(2)}</td>
                  <td className="py-3 px-4">
                    {new Date(order.createdAt).toLocaleDateString("ar-SA")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

// Users Table Component
function UsersTable() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>المستخدمون</CardTitle>
        <CardDescription>قائمة المستخدمين المسجلين</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="text-center py-8 text-gray-500">
          <p>لا توجد بيانات مستخدمين حالياً</p>
        </div>
      </CardContent>
    </Card>
  );
}

// Settings Panel Component
function SettingsPanel() {
  const [storeName, setStoreName] = useState("IB Pharmacy");
  const [storeEmail, setStoreEmail] = useState("info@ibpharmacy.com");

  return (
    <Card>
      <CardHeader>
        <CardTitle>إعدادات المتجر</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">اسم المتجر</label>
          <Input
            value={storeName}
            onChange={(e) => setStoreName(e.target.value)}
            placeholder="اسم المتجر"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">البريد الإلكتروني</label>
          <Input
            type="email"
            value={storeEmail}
            onChange={(e) => setStoreEmail(e.target.value)}
            placeholder="البريد الإلكتروني"
          />
        </div>

        <Button className="bg-gradient-to-r from-green-600 to-green-700">
          حفظ الإعدادات
        </Button>
      </CardContent>
    </Card>
  );
}
