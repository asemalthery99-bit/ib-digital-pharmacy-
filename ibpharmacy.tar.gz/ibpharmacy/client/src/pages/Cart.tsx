import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, Trash2, ShoppingCart, ArrowRight } from "lucide-react";
import { toast } from "sonner";

interface CartItem {
  productId: number;
  quantity: number;
}

export default function Cart() {
  const [, navigate] = useLocation();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const cartQuery = trpc.cart.get.useQuery();
  const cartMutation = trpc.cart.update.useMutation();
  const productsQuery = trpc.products.list.useQuery();
  const createOrderMutation = trpc.orders.create.useMutation();

  // Load cart items
  useEffect(() => {
    if (cartQuery.data?.items) {
      setCartItems(cartQuery.data.items as CartItem[]);
    }
    setIsLoading(false);
  }, [cartQuery.data]);

  // Get product details for cart items
  const cartProducts = cartItems
    .map(item => productsQuery.data?.find(p => p.id === item.productId))
    .filter(Boolean);

  // Calculate totals
  const subtotal = cartItems.reduce((sum, item) => {
    const product = productsQuery.data?.find(p => p.id === item.productId);
    return sum + (product ? Number(product.price) * item.quantity : 0);
  }, 0);

  const tax = subtotal * 0.1; // 10% tax
  const total = subtotal + tax;

  const handleUpdateQuantity = async (productId: number, newQuantity: number) => {
    if (newQuantity < 0) return;

    const newItems = newQuantity === 0
      ? cartItems.filter(item => item.productId !== productId)
      : cartItems.map(item =>
          item.productId === productId ? { ...item, quantity: newQuantity } : item
        );

    setCartItems(newItems);
    await cartMutation.mutateAsync({ items: newItems });
  };

  const handleRemoveItem = async (productId: number) => {
    const newItems = cartItems.filter(item => item.productId !== productId);
    setCartItems(newItems);
    await cartMutation.mutateAsync({ items: newItems });
    toast.success("تم حذف المنتج من السلة");
  };

  const handleCheckout = async () => {
    if (cartItems.length === 0) {
      toast.error("السلة فارغة");
      return;
    }

    try {
      const order = await createOrderMutation.mutateAsync({
        shippingAddress: "سيتم تحديده لاحقاً",
        items: cartItems,
      });

      toast.success("تم إنشاء الطلب بنجاح");
      setCartItems([]);
      await cartMutation.mutateAsync({ items: [] });

      // Navigate to payment
      navigate(`/payment/${order.orderId}`);
    } catch (error: any) {
      toast.error(error.message || "فشل إنشاء الطلب");
    }
  };

  if (isLoading || productsQuery.isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-green-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <ShoppingCart className="w-8 h-8 text-green-600" />
            <h1 className="text-3xl font-bold">سلتك</h1>
          </div>
          <p className="text-gray-600">
            {cartItems.length} {cartItems.length === 1 ? "منتج" : "منتجات"} في السلة
          </p>
        </div>

        {cartItems.length === 0 ? (
          <Card className="text-center py-16">
            <CardContent>
              <div className="mb-4">
                <ShoppingCart className="w-16 h-16 mx-auto text-gray-300" />
              </div>
              <h2 className="text-2xl font-bold mb-2">السلة فارغة</h2>
              <p className="text-gray-600 mb-6">لم تضف أي منتجات إلى السلة بعد</p>
              <Button
                onClick={() => navigate("/products")}
                className="bg-gradient-to-r from-green-600 to-green-700"
              >
                <ArrowRight className="w-4 h-4 mr-2" />
                تصفح المنتجات
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map(item => {
                const product = productsQuery.data?.find(p => p.id === item.productId);
                if (!product) return null;

                return (
                  <Card key={item.productId} className="overflow-hidden">
                    <CardContent className="p-6">
                      <div className="flex gap-4">
                        {/* Product Image */}
                        <div className="w-24 h-24 bg-gradient-to-br from-green-100 to-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          {product.image ? (
                            <img
                              src={product.image}
                              alt={product.name}
                              className="w-full h-full object-cover rounded-lg"
                            />
                          ) : (
                            <span className="text-3xl">💊</span>
                          )}
                        </div>

                        {/* Product Details */}
                        <div className="flex-1">
                          <h3 className="font-bold text-lg mb-1">{product.name}</h3>
                          <p className="text-sm text-gray-600 mb-2">{product.category}</p>
                          <p className="text-2xl font-bold text-green-600">
                            ${Number(product.price).toFixed(2)}
                          </p>
                        </div>

                        {/* Quantity and Actions */}
                        <div className="flex flex-col items-end justify-between">
                          <button
                            onClick={() => handleRemoveItem(item.productId)}
                            className="text-red-500 hover:text-red-700 transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>

                          <div className="flex items-center gap-2 border rounded-lg p-1">
                            <button
                              onClick={() => handleUpdateQuantity(item.productId, item.quantity - 1)}
                              className="px-2 py-1 hover:bg-gray-100 rounded"
                            >
                              −
                            </button>
                            <Input
                              type="number"
                              value={item.quantity}
                              onChange={(e) =>
                                handleUpdateQuantity(item.productId, parseInt(e.target.value) || 0)
                              }
                              className="w-12 text-center border-0"
                            />
                            <button
                              onClick={() => handleUpdateQuantity(item.productId, item.quantity + 1)}
                              className="px-2 py-1 hover:bg-gray-100 rounded"
                            >
                              +
                            </button>
                          </div>

                          <p className="font-bold text-lg">
                            ${(Number(product.price) * item.quantity).toFixed(2)}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-4">
                <CardHeader>
                  <CardTitle>ملخص الطلب</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2 border-b pb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">المجموع الفرعي:</span>
                      <span className="font-medium">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">الضريبة (10%):</span>
                      <span className="font-medium">${tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">التوصيل:</span>
                      <span className="font-medium text-green-600">مجاني</span>
                    </div>
                  </div>

                  <div className="flex justify-between text-lg font-bold">
                    <span>الإجمالي:</span>
                    <span className="text-green-600">${total.toFixed(2)}</span>
                  </div>

                  <Button
                    onClick={handleCheckout}
                    disabled={createOrderMutation.isPending}
                    className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold py-3"
                  >
                    {createOrderMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        جاري المعالجة...
                      </>
                    ) : (
                      "متابعة إلى الدفع"
                    )}
                  </Button>

                  <Button
                    variant="outline"
                    onClick={() => navigate("/products")}
                    className="w-full"
                  >
                    متابعة التسوق
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
