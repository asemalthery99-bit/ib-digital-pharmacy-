import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, ShoppingCart, Heart, Share2, AlertCircle, CheckCircle, Package } from "lucide-react";
import { toast } from "sonner";

interface ProductDetailProps {
  productId?: string;
}

export default function ProductDetail({ productId }: ProductDetailProps) {
  const [quantity, setQuantity] = useState(1);
  const [isFavorite, setIsFavorite] = useState(false);
  const { user } = useAuth();
  const [, navigate] = useLocation();

  // Mock product data - في الإنتاج سيأتي من API
  const product = {
    id: parseInt(productId || "1"),
    name: "أسبرين 500 ملغ",
    category: "مسكنات ومخفضات الحرارة",
    price: "15.99",
    stock: 150,
    rating: 4.5,
    reviews: 128,
    image: "https://via.placeholder.com/400x400?text=Aspirin",
    description: "أسبرين فعال لتخفيف الآلام والحمى. يستخدم لتسكين الآلام الخفيفة إلى المتوسطة.",
    manufacturer: "شركة الدواء الموثوقة",
    activeIngredient: "حمض الأسيتيل ساليسيليك",
    dosage: "500 ملغ",
    form: "أقراص",
    quantity_per_pack: "20 قرص",
    expiry_date: "2026-12-31",
    storage: "درجة حرارة الغرفة (15-25°م)",
    contraindications: [
      "الحساسية من الأسبرين",
      "قرحة المعدة النشطة",
      "الحمل (خاصة في الثلث الثالث)",
      "الرضاعة الطبيعية",
    ],
    side_effects: [
      "اضطراب في المعدة",
      "حموضة",
      "طفح جلدي",
      "نزيف (نادر)",
    ],
    usage: "تناول 1-2 قرص كل 4-6 ساعات حسب الحاجة، بحد أقصى 3000 ملغ يومياً",
    warnings: [
      "لا تتجاوز الجرعة الموصى بها",
      "قد يسبب حساسية لدى بعض الأشخاص",
      "استشر الطبيب قبل الاستخدام إذا كنت تتناول أدوية أخرى",
    ],
  };

  const addToCartMutation = trpc.cart.update.useMutation();

  const handleAddToCart = async () => {
    if (!user) {
      navigate("/");
      toast.error("الرجاء تسجيل الدخول أولاً");
      return;
    }

    try {
      await addToCartMutation.mutateAsync({
        items: [
          {
            productId: product.id,
            quantity,
          },
        ],
      });
      toast.success(`تمت إضافة ${quantity} من ${product.name} إلى السلة`);
      setQuantity(1);
    } catch (error: any) {
      toast.error(error.message || "فشل إضافة المنتج إلى السلة");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <div className="mb-6 flex items-center gap-2 text-sm text-gray-600">
          <button onClick={() => navigate("/")} className="hover:text-green-600">
            الرئيسية
          </button>
          <span>/</span>
          <button onClick={() => navigate("/products")} className="hover:text-green-600">
            المنتجات
          </button>
          <span>/</span>
          <span className="text-green-600 font-medium">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Product Image */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardContent className="p-0">
                <div className="w-full bg-gray-100 rounded-t-lg overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-96 object-cover"
                  />
                </div>
                <div className="p-4 space-y-3">
                  <Button
                    onClick={handleAddToCart}
                    disabled={addToCartMutation.isPending || product.stock === 0}
                    className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
                  >
                    {addToCartMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        جاري الإضافة...
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        أضف إلى السلة
                      </>
                    )}
                  </Button>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => setIsFavorite(!isFavorite)}
                    >
                      <Heart
                        className={`w-4 h-4 mr-2 ${isFavorite ? "fill-red-600 text-red-600" : ""}`}
                      />
                      {isFavorite ? "مفضل" : "إضافة"}
                    </Button>
                    <Button variant="outline" className="flex-1">
                      <Share2 className="w-4 h-4 mr-2" />
                      مشاركة
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Product Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Header */}
            <div>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
                  <p className="text-gray-600">{product.category}</p>
                </div>
                <Badge className="bg-green-100 text-green-800">{product.dosage}</Badge>
              </div>

              {/* Rating */}
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <span
                      key={i}
                      className={`text-lg ${
                        i < Math.floor(product.rating)
                          ? "text-yellow-400"
                          : "text-gray-300"
                      }`}
                    >
                      ★
                    </span>
                  ))}
                </div>
                <span className="text-sm text-gray-600">
                  {product.rating} من 5 ({product.reviews} تقييم)
                </span>
              </div>

              {/* Price and Stock */}
              <div className="flex items-center gap-6 mb-4">
                <div>
                  <p className="text-gray-600 text-sm">السعر</p>
                  <p className="text-3xl font-bold text-green-600">${product.price}</p>
                </div>
                <div>
                  <p className="text-gray-600 text-sm">المخزون</p>
                  <div className="flex items-center gap-2">
                    {product.stock > 0 ? (
                      <>
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        <span className="font-medium">{product.stock} متوفر</span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-5 h-5 text-red-600" />
                        <span className="font-medium text-red-600">غير متوفر</span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Quantity Selector */}
              <div className="flex items-center gap-4">
                <label className="text-sm font-medium">الكمية:</label>
                <div className="flex items-center border rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-2 hover:bg-gray-100"
                  >
                    −
                  </button>
                  <Input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-16 border-0 text-center"
                    min="1"
                    max={product.stock}
                  />
                  <button
                    onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                    className="px-3 py-2 hover:bg-gray-100"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* Tabs */}
            <Tabs defaultValue="info" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="info">المعلومات</TabsTrigger>
                <TabsTrigger value="usage">الاستخدام</TabsTrigger>
                <TabsTrigger value="warnings">التحذيرات</TabsTrigger>
                <TabsTrigger value="reviews">التقييمات</TabsTrigger>
              </TabsList>

              {/* Info Tab */}
              <TabsContent value="info">
                <Card>
                  <CardHeader>
                    <CardTitle>معلومات المنتج</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">الشركة المصنعة</p>
                        <p className="font-medium">{product.manufacturer}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">المادة الفعالة</p>
                        <p className="font-medium">{product.activeIngredient}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">الشكل الصيدلاني</p>
                        <p className="font-medium">{product.form}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">الكمية في العبوة</p>
                        <p className="font-medium">{product.quantity_per_pack}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">تاريخ الانتهاء</p>
                        <p className="font-medium">{product.expiry_date}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">التخزين</p>
                        <p className="font-medium">{product.storage}</p>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm text-gray-600 mb-2">الوصف</p>
                      <p className="text-gray-700">{product.description}</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Usage Tab */}
              <TabsContent value="usage">
                <Card>
                  <CardHeader>
                    <CardTitle>طريقة الاستخدام</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-sm text-gray-600 mb-2">الجرعة الموصى بها:</p>
                      <p className="text-gray-700 bg-blue-50 p-3 rounded-lg">{product.usage}</p>
                    </div>

                    <div>
                      <p className="text-sm text-gray-600 mb-2">موانع الاستخدام:</p>
                      <ul className="space-y-2">
                        {product.contraindications.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <AlertCircle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <p className="text-sm text-gray-600 mb-2">الآثار الجانبية المحتملة:</p>
                      <ul className="space-y-2">
                        {product.side_effects.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Warnings Tab */}
              <TabsContent value="warnings">
                <Card className="border-orange-200 bg-orange-50">
                  <CardHeader>
                    <CardTitle className="text-orange-900">تحذيرات مهمة</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {product.warnings.map((warning, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                          <span className="text-orange-900">{warning}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="mt-4 p-3 bg-white rounded-lg border border-orange-200">
                      <p className="text-sm text-orange-900">
                        <strong>ملاحظة:</strong> هذه المعلومات لأغراض تعليمية فقط. استشر الصيدلاني أو الطبيب قبل الاستخدام.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Reviews Tab */}
              <TabsContent value="reviews">
                <Card>
                  <CardHeader>
                    <CardTitle>التقييمات</CardTitle>
                    <CardDescription>
                      {product.reviews} تقييم من المستخدمين
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8 text-gray-500">
                      <Package className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                      <p>لا توجد تقييمات حتى الآن</p>
                      <p className="text-sm mt-2">كن أول من يقيّم هذا المنتج!</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}
