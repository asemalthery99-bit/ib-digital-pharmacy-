import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, CheckCircle, AlertCircle, ShoppingCart, Truck, MessageSquare, Trash2 } from "lucide-react";
import { toast } from "sonner";

interface Notification {
  id: number;
  type: "order" | "delivery" | "consultation" | "promotion";
  title: string;
  message: string;
  read: boolean;
  createdAt: Date;
  icon?: React.ReactNode;
}

export default function Notifications() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 1,
      type: "order",
      title: "تم تأكيد طلبك",
      message: "تم تأكيد طلبك #1001 بنجاح. سيتم معالجته قريباً.",
      read: false,
      createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
    },
    {
      id: 2,
      type: "delivery",
      title: "الطلب في الطريق",
      message: "طلبك #1001 في الطريق إليك. سيصل خلال 2 ساعة.",
      read: false,
      createdAt: new Date(Date.now() - 30 * 60 * 1000),
    },
    {
      id: 3,
      type: "consultation",
      title: "رد على استشارتك",
      message: "تم الرد على سؤالك حول الأسبرين. اضغط لعرض الإجابة.",
      read: true,
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    },
    {
      id: 4,
      type: "promotion",
      title: "عرض خاص",
      message: "احصل على خصم 20% على جميع المنتجات اليوم فقط!",
      read: true,
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
    },
  ]);

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "order":
        return <ShoppingCart className="w-5 h-5 text-blue-600" />;
      case "delivery":
        return <Truck className="w-5 h-5 text-green-600" />;
      case "consultation":
        return <MessageSquare className="w-5 h-5 text-purple-600" />;
      case "promotion":
        return <AlertCircle className="w-5 h-5 text-orange-600" />;
      default:
        return <Bell className="w-5 h-5 text-gray-600" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "order":
        return "bg-blue-50 border-blue-200";
      case "delivery":
        return "bg-green-50 border-green-200";
      case "consultation":
        return "bg-purple-50 border-purple-200";
      case "promotion":
        return "bg-orange-50 border-orange-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  const handleMarkAsRead = (id: number) => {
    setNotifications(
      notifications.map(n => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const handleDelete = (id: number) => {
    setNotifications(notifications.filter(n => n.id !== id));
    toast.success("تم حذف الإشعار");
  };

  const handleMarkAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
    toast.success("تم تحديث جميع الإشعارات");
  };

  const unreadCount = notifications.filter(n => !n.read).length;
  const readNotifications = notifications.filter(n => n.read);
  const unreadNotifications = notifications.filter(n => !n.read);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Bell className="w-8 h-8 text-green-600" />
            <h1 className="text-3xl font-bold">الإشعارات</h1>
          </div>
          <p className="text-gray-600">
            لديك {unreadCount} إشعار جديد من أصل {notifications.length} إشعار
          </p>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="unread" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="unread">
              الجديدة ({unreadCount})
            </TabsTrigger>
            <TabsTrigger value="read">
              المقروءة ({readNotifications.length})
            </TabsTrigger>
          </TabsList>

          {/* Unread Tab */}
          <TabsContent value="unread" className="space-y-4">
            {unreadNotifications.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <CheckCircle className="w-12 h-12 mx-auto text-green-600 mb-4" />
                  <p className="text-gray-600 font-medium">لا توجد إشعارات جديدة</p>
                  <p className="text-sm text-gray-500 mt-2">
                    أنت على اطلاع بجميع آخر التحديثات
                  </p>
                </CardContent>
              </Card>
            ) : (
              <>
                <div className="flex justify-end mb-4">
                  <Button
                    variant="outline"
                    onClick={handleMarkAllAsRead}
                    className="text-sm"
                  >
                    تحديد الكل كمقروء
                  </Button>
                </div>
                {unreadNotifications.map(notification => (
                  <Card
                    key={notification.id}
                    className={`border ${getNotificationColor(notification.type)} cursor-pointer hover:shadow-md transition-shadow`}
                    onClick={() => handleMarkAsRead(notification.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <div className="mt-1">
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <h3 className="font-bold text-gray-900">
                                {notification.title}
                              </h3>
                              <p className="text-gray-700 mt-1">
                                {notification.message}
                              </p>
                            </div>
                            <Badge className="bg-green-600 text-white flex-shrink-0">
                              جديد
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-500 mt-2">
                            {notification.createdAt.toLocaleString("ar-SA")}
                          </p>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(notification.id);
                          }}
                          className="text-gray-400 hover:text-red-600 transition-colors flex-shrink-0"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </>
            )}
          </TabsContent>

          {/* Read Tab */}
          <TabsContent value="read" className="space-y-4">
            {readNotifications.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Bell className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-600 font-medium">لا توجد إشعارات مقروءة</p>
                </CardContent>
              </Card>
            ) : (
              readNotifications.map(notification => (
                <Card
                  key={notification.id}
                  className={`border ${getNotificationColor(notification.type)} opacity-75`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="mt-1">
                        {getNotificationIcon(notification.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h3 className="font-bold text-gray-900">
                              {notification.title}
                            </h3>
                            <p className="text-gray-700 mt-1">
                              {notification.message}
                            </p>
                          </div>
                        </div>
                        <p className="text-xs text-gray-500 mt-2">
                          {notification.createdAt.toLocaleString("ar-SA")}
                        </p>
                      </div>
                      <button
                        onClick={() => handleDelete(notification.id)}
                        className="text-gray-400 hover:text-red-600 transition-colors flex-shrink-0"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>

        {/* Notification Settings */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>إعدادات الإشعارات</CardTitle>
            <CardDescription>
              تحكم في نوع الإشعارات التي تريد استقبالها
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">إشعارات الطلبات</p>
                <p className="text-sm text-gray-600">
                  اعرف عندما يتم تأكيد أو تحديث طلباتك
                </p>
              </div>
              <input type="checkbox" defaultChecked className="w-5 h-5" />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">إشعارات التوصيل</p>
                <p className="text-sm text-gray-600">
                  اعرف عندما يكون طلبك في الطريق
                </p>
              </div>
              <input type="checkbox" defaultChecked className="w-5 h-5" />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">إشعارات الاستشارات</p>
                <p className="text-sm text-gray-600">
                  اعرف عندما يتم الرد على استشاراتك
                </p>
              </div>
              <input type="checkbox" defaultChecked className="w-5 h-5" />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">إشعارات العروض الترويجية</p>
                <p className="text-sm text-gray-600">
                  اعرف عن العروض الخاصة والخصومات
                </p>
              </div>
              <input type="checkbox" defaultChecked className="w-5 h-5" />
            </div>

            <Button className="w-full bg-green-600 hover:bg-green-700 mt-4">
              حفظ الإعدادات
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
