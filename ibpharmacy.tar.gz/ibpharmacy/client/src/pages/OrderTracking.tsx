import { useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, MapPin, Phone, Clock, Package } from "lucide-react";
import { toast } from "sonner";

interface OrderTrackingProps {
  orderId?: string;
}

export default function OrderTracking({ orderId }: OrderTrackingProps) {
  const [, navigate] = useLocation();
  const mapRef = useRef<HTMLDivElement>(null);

  // Mock order data
  const order = {
    id: parseInt(orderId || "1"),
    status: "shipped",
    totalAmount: "45.99",
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    estimatedDelivery: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
    shippingAddress: "شارع النيل، القاهرة، مصر",
    items: [
      { id: 1, name: "أسبرين 500 ملغ", quantity: 2, price: "15.99" },
      { id: 2, name: "فيتامين C", quantity: 1, price: "14.01" },
    ],
    deliveryPerson: {
      name: "أحمد محمد",
      phone: "+20 100 123 4567",
      vehicle: "دراجة نارية - رقم 123",
    },
    timeline: [
      { status: "confirmed", label: "تم تأكيد الطلب", time: "2026-03-10 10:30", completed: true },
      { status: "processing", label: "جاري معالجة الطلب", time: "2026-03-10 11:00", completed: true },
      { status: "ready", label: "جاهز للتوصيل", time: "2026-03-10 14:00", completed: true },
      { status: "shipped", label: "في الطريق", time: "2026-03-11 08:00", completed: true },
      { status: "delivered", label: "تم التسليم", time: "2026-03-12 18:00", completed: false },
    ],
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-blue-100 text-blue-800";
      case "processing":
        return "bg-yellow-100 text-yellow-800";
      case "ready":
        return "bg-purple-100 text-purple-800";
      case "shipped":
        return "bg-green-100 text-green-800";
      case "delivered":
        return "bg-green-600 text-white";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      confirmed: "مؤكد",
      processing: "قيد المعالجة",
      ready: "جاهز",
      shipped: "في الطريق",
      delivered: "تم التسليم",
    };
    return labels[status] || status;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">تتبع الطلب</h1>
          <p className="text-gray-600">رقم الطلب: #{order.id}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Map Section */}
          <div className="lg:col-span-2">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>خريطة التوصيل</CardTitle>
                <CardDescription>موقع الطلب في الوقت الفعلي</CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  ref={mapRef}
                  className="w-full h-96 bg-gray-100 rounded-lg flex items-center justify-center"
                >
                  <div className="text-center">
                    <MapPin className="w-12 h-12 mx-auto text-gray-400 mb-2" />
                    <p className="text-gray-500">خريطة Google Maps</p>
                    <p className="text-xs text-gray-400 mt-2">
                      سيتم عرض الخريطة التفاعلية هنا
                    </p>
                  </div>
                </div>

                {/* Delivery Info */}
                <div className="mt-6 p-4 bg-green-50 rounded-lg border border-green-200">
                  <h3 className="font-bold text-green-900 mb-3">معلومات التوصيل</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Package className="w-5 h-5 text-green-600 mt-0.5" />
                      <div>
                        <p className="text-sm text-gray-600">العنوان</p>
                        <p className="font-medium">{order.shippingAddress}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock className="w-5 h-5 text-green-600 mt-0.5" />
                      <div>
                        <p className="text-sm text-gray-600">التسليم المتوقع</p>
                        <p className="font-medium">
                          {order.estimatedDelivery.toLocaleDateString("ar-SA", {
                            weekday: "long",
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Status Card */}
            <Card>
              <CardHeader>
                <CardTitle>حالة الطلب</CardTitle>
              </CardHeader>
              <CardContent>
                <Badge className={`${getStatusColor(order.status)} text-base py-2 px-3`}>
                  {getStatusLabel(order.status)}
                </Badge>
              </CardContent>
            </Card>

            {/* Delivery Person Card */}
            {order.status === "shipped" && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">سائق التوصيل</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-600">الاسم</p>
                    <p className="font-medium">{order.deliveryPerson.name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">رقم الهاتف</p>
                    <a
                      href={`tel:${order.deliveryPerson.phone}`}
                      className="font-medium text-green-600 hover:underline flex items-center gap-2"
                    >
                      <Phone className="w-4 h-4" />
                      {order.deliveryPerson.phone}
                    </a>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">المركبة</p>
                    <p className="font-medium">{order.deliveryPerson.vehicle}</p>
                  </div>
                  <Button className="w-full bg-green-600 hover:bg-green-700">
                    اتصل بالسائق
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Order Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">ملخص الطلب</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  {order.items.map(item => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span>{item.name}</span>
                      <span className="text-gray-600">x{item.quantity}</span>
                    </div>
                  ))}
                </div>
                <div className="border-t pt-3">
                  <div className="flex justify-between font-bold">
                    <span>الإجمالي</span>
                    <span className="text-green-600">${order.totalAmount}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Timeline */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>مسار الطلب</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {order.timeline.map((step, idx) => (
                <div key={idx} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                        step.completed ? "bg-green-600" : "bg-gray-300"
                      }`}
                    >
                      {step.completed ? "✓" : idx + 1}
                    </div>
                    {idx < order.timeline.length - 1 && (
                      <div
                        className={`w-0.5 h-12 ${
                          step.completed ? "bg-green-600" : "bg-gray-300"
                        }`}
                      />
                    )}
                  </div>
                  <div className="pb-4">
                    <p className="font-medium">{step.label}</p>
                    <p className="text-sm text-gray-600">{step.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="mt-8 flex gap-4 justify-center">
          <Button onClick={() => navigate("/orders")} variant="outline">
            العودة للطلبات
          </Button>
          <Button className="bg-green-600 hover:bg-green-700">
            تحديث الحالة
          </Button>
        </div>
      </div>
    </div>
  );
}
