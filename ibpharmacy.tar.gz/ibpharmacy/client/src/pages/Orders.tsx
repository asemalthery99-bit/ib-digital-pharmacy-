import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Package, Clock, CheckCircle, Truck, MapPin } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

const statusConfig = {
  pending: {
    label: "قيد الانتظار",
    color: "bg-yellow-100 text-yellow-800",
    icon: Clock,
  },
  processing: {
    label: "قيد المعالجة",
    color: "bg-blue-100 text-blue-800",
    icon: Package,
  },
  ready: {
    label: "جاهز للتوصيل",
    color: "bg-purple-100 text-purple-800",
    icon: Truck,
  },
  shipped: {
    label: "قيد التوصيل",
    color: "bg-orange-100 text-orange-800",
    icon: Truck,
  },
  delivered: {
    label: "تم التسليم",
    color: "bg-green-100 text-green-800",
    icon: CheckCircle,
  },
  cancelled: {
    label: "ملغى",
    color: "bg-red-100 text-red-800",
    icon: Clock,
  },
};

export default function Orders() {
  const [, navigate] = useLocation();
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);

  const ordersQuery = trpc.orders.list.useQuery();
  const selectedOrderQuery = trpc.orders.getById.useQuery(
    { id: selectedOrderId || 0 },
    { enabled: !!selectedOrderId }
  );

  if (ordersQuery.isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-green-600" />
      </div>
    );
  }

  const orders = ordersQuery.data || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">طلباتي</h1>
          <p className="text-gray-600">
            {orders.length} {orders.length === 1 ? "طلب" : "طلبات"}
          </p>
        </div>

        {orders.length === 0 ? (
          <Card className="text-center py-16">
            <CardContent>
              <div className="mb-4">
                <Package className="w-16 h-16 mx-auto text-gray-300" />
              </div>
              <h2 className="text-2xl font-bold mb-2">لا توجد طلبات</h2>
              <p className="text-gray-600 mb-6">لم تقم بأي طلبات حتى الآن</p>
              <Button
                onClick={() => navigate("/products")}
                className="bg-gradient-to-r from-green-600 to-green-700"
              >
                ابدأ التسوق
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Orders List */}
            <div className="lg:col-span-2 space-y-4">
              {orders.map(order => {
                const config = statusConfig[order.status as keyof typeof statusConfig];
                const StatusIcon = config?.icon || Clock;

                return (
                  <Card
                    key={order.id}
                    className="cursor-pointer hover:shadow-lg transition-shadow"
                    onClick={() => setSelectedOrderId(order.id)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="font-bold text-lg">الطلب #{order.id}</h3>
                          <p className="text-sm text-gray-500">
                            {formatDistanceToNow(new Date(order.createdAt), {
                              addSuffix: true,
                              locale: ar,
                            })}
                          </p>
                        </div>
                        <Badge className={config?.color}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {config?.label}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-3 gap-4 py-4 border-t border-b">
                        <div>
                          <p className="text-xs text-gray-500 mb-1">الإجمالي</p>
                          <p className="font-bold text-green-600">
                            ${Number(order.totalAmount).toFixed(2)}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 mb-1">عدد المنتجات</p>
                          <p className="font-bold">{order.items?.length || 0}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 mb-1">الحالة</p>
                          <p className="font-bold text-blue-600">
                            {config?.label}
                          </p>
                        </div>
                      </div>

                      <div className="mt-4 flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedOrderId(order.id)}
                        >
                          عرض التفاصيل
                        </Button>
                        {order.status === "ready" || order.status === "shipped" ? (
                          <Button size="sm" variant="outline" className="text-blue-600">
                            <MapPin className="w-4 h-4 mr-1" />
                            تتبع الطلب
                          </Button>
                        ) : null}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Order Details */}
            <div className="lg:col-span-1">
              {selectedOrderId && selectedOrderQuery.data ? (
                <Card className="sticky top-4">
                  <CardHeader>
                    <CardTitle>تفاصيل الطلب</CardTitle>
                    <CardDescription>الطلب #{selectedOrderId}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Status */}
                    <div>
                      <p className="text-sm text-gray-600 mb-2">الحالة</p>
                      <Badge className={statusConfig[selectedOrderQuery.data.status as keyof typeof statusConfig]?.color}>
                        {statusConfig[selectedOrderQuery.data.status as keyof typeof statusConfig]?.label}
                      </Badge>
                    </div>

                    {/* Items */}
                    <div>
                      <p className="text-sm font-bold mb-2">المنتجات</p>
                      <div className="space-y-2">
                        {(selectedOrderQuery.data as any).items?.map((item: any) => (
                          <div key={item.id} className="text-sm flex justify-between">
                            <span className="text-gray-600">
                              المنتج #{item.productId} × {item.quantity}
                            </span>
                            <span className="font-medium">
                              ${(Number(item.price) * item.quantity).toFixed(2)}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Totals */}
                    <div className="border-t pt-4 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">المجموع الفرعي:</span>
                        <span className="font-medium">
                          ${Number((selectedOrderQuery.data as any).totalAmount).toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between text-lg font-bold text-green-600">
                        <span>الإجمالي:</span>
                        <span>${Number((selectedOrderQuery.data as any).totalAmount).toFixed(2)}</span>
                      </div>
                    </div>

                    {/* Shipping Address */}
                    <div className="bg-gray-50 p-3 rounded">
                      <p className="text-xs text-gray-600 mb-1">عنوان التوصيل</p>
                      <p className="text-sm">{(selectedOrderQuery.data as any).shippingAddress}</p>
                    </div>

                    {/* Notes */}
                    {(selectedOrderQuery.data as any).notes && (
                      <div className="bg-blue-50 p-3 rounded">
                        <p className="text-xs text-gray-600 mb-1">ملاحظات</p>
                        <p className="text-sm">{(selectedOrderQuery.data as any).notes}</p>
                      </div>
                    )}

                    {/* Timeline */}
                    <div className="space-y-3">
                      <p className="text-sm font-bold">المسار</p>
                      <div className="space-y-2">
                        <div className="flex gap-3">
                          <div className="w-2 h-2 bg-green-600 rounded-full mt-1.5 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-medium">تم إنشاء الطلب</p>
                          <p className="text-xs text-gray-500">
                            {new Date((selectedOrderQuery.data as any).createdAt).toLocaleDateString("ar-SA")}
                          </p>
                        </div>
                        </div>
                        {(selectedOrderQuery.data as any).status !== "pending" && (
                          <div className="flex gap-3">
                            <div className="w-2 h-2 bg-blue-600 rounded-full mt-1.5 flex-shrink-0" />
                            <div>
                              <p className="text-sm font-medium">قيد المعالجة</p>
                            <p className="text-xs text-gray-500">
                              {new Date((selectedOrderQuery.data as any).updatedAt).toLocaleDateString("ar-SA")}
                            </p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="sticky top-4">
                  <CardContent className="p-6 text-center text-gray-500">
                    اختر طلباً لعرض التفاصيل
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
