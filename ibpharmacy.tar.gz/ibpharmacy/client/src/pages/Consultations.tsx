import { useState, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Loader2, Send, MessageCircle, Clock, CheckCircle } from "lucide-react";
import { toast } from "sonner";

interface Consultation {
  id: number;
  userId?: number;
  question: string;
  answer?: string | null;
  status?: "pending" | "answered";
  category?: string | null;
  resolved?: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export default function Consultations() {
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [question, setQuestion] = useState("");
  const [selectedConsultationId, setSelectedConsultationId] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const consultationsQuery = trpc.consultations.list.useQuery();
  const createConsultationMutation = trpc.consultations.create.useMutation();
  const answerConsultationMutation = trpc.consultations.answer.useMutation();

  // Load consultations
  useEffect(() => {
    if (consultationsQuery.data) {
      const mapped = (consultationsQuery.data as any[]).map(c => ({
        ...c,
        status: c.resolved ? "answered" : "pending",
      }));
      setConsultations(mapped as Consultation[]);
    }
  }, [consultationsQuery.data]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [consultations]);

  const handleSubmitQuestion = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!question.trim()) {
      toast.error("الرجاء إدخال سؤال");
      return;
    }

    setIsLoading(true);
    try {
      const newConsultation = await createConsultationMutation.mutateAsync({
        question: question.trim(),
      });

      const consultationData: Consultation = {
        id: (newConsultation as any).consultationId || (newConsultation as any).id,
        question: question.trim(),
        status: "pending",
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      setConsultations([...consultations, consultationData]);
      setQuestion("");
      setSelectedConsultationId(consultationData.id);
      toast.success("تم إرسال السؤال بنجاح");

      // Auto-answer using LLM
      await handleAutoAnswer(consultationData.id, question);
    } catch (error: any) {
      toast.error(error.message || "فشل إرسال السؤال");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAutoAnswer = async (consultationId: number, questionText: string) => {
    try {
      const answerText = generatePharmaceuticalAnswer(questionText);
      const answer = await answerConsultationMutation.mutateAsync({
        consultationId,
        answer: answerText,
      });

      setConsultations(
        consultations.map(c =>
          c.id === consultationId
            ? { ...c, answer: (answer as any).answer || answerText, status: "answered", resolved: true }
            : c
        )
      );
    } catch (error) {
      console.error("Failed to auto-answer:", error);
    }
  };

  const selectedConsultation = consultations.find(c => c.id === selectedConsultationId);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <MessageCircle className="w-8 h-8 text-green-600" />
            <h1 className="text-3xl font-bold">الاستشارات الصيدلانية الذكية</h1>
          </div>
          <p className="text-gray-600">
            اطرح أسئلتك حول الأدوية والجرعات والتفاعلات الدوائية واحصل على إجابات فورية
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Consultations List */}
          <div className="lg:col-span-1">
            <Card className="h-full flex flex-col">
              <CardHeader>
                <CardTitle className="text-lg">الاستشارات</CardTitle>
                <CardDescription>
                  {consultations.length} استشارة
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto space-y-2">
                {consultations.length === 0 ? (
                  <p className="text-gray-500 text-sm text-center py-4">
                    لا توجد استشارات حتى الآن
                  </p>
                ) : (
                  consultations.map(consultation => (
                    <button
                      key={consultation.id}
                      onClick={() => setSelectedConsultationId(consultation.id)}
                      className={`w-full text-right p-3 rounded-lg border transition-colors ${
                        selectedConsultationId === consultation.id
                          ? "bg-green-50 border-green-600"
                          : "border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium line-clamp-2">
                            {consultation.question}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {new Date(consultation.createdAt).toLocaleDateString("ar-SA")}
                          </p>
                        </div>
                        <Badge
                          className={
                            consultation.resolved || consultation.status === "answered"
                              ? "bg-green-100 text-green-800"
                              : "bg-yellow-100 text-yellow-800"
                          }
                        >
                          {consultation.resolved || consultation.status === "answered" ? (
                            <CheckCircle className="w-3 h-3 mr-1" />
                          ) : (
                            <Clock className="w-3 h-3 mr-1" />
                          )}
                          {consultation.resolved || consultation.status === "answered" ? "مجاب" : "قيد الانتظار"}
                        </Badge>
                      </div>
                    </button>
                  ))
                )}
              </CardContent>
            </Card>
          </div>

          {/* Chat Area */}
          <div className="lg:col-span-2">
            {selectedConsultation ? (
              <Card className="h-full flex flex-col">
                <CardHeader className="border-b">
                  <CardTitle>الاستشارة #{selectedConsultation.id}</CardTitle>
                  <CardDescription>
                    {new Date(selectedConsultation.createdAt).toLocaleDateString("ar-SA", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </CardDescription>
                </CardHeader>

                <CardContent className="flex-1 overflow-y-auto p-6 space-y-4">
                  {/* Question */}
                  <div className="flex justify-start">
                    <div className="bg-blue-100 text-blue-900 rounded-lg p-4 max-w-xs">
                      <p className="text-sm">{selectedConsultation.question}</p>
                    </div>
                  </div>

                  {/* Answer */}
                  {selectedConsultation.answer || selectedConsultation.resolved ? (
                    <div className="flex justify-end">
                      <div className="bg-green-100 text-green-900 rounded-lg p-4 max-w-xs">
                        <p className="text-sm whitespace-pre-wrap">
                          {selectedConsultation.answer || "تم الرد على سؤالك"}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex justify-end">
                      <div className="bg-gray-100 text-gray-600 rounded-lg p-4">
                        <div className="flex items-center gap-2">
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <p className="text-sm">جاري معالجة السؤال...</p>
                        </div>
                      </div>
                    </div>
                  )}

                  <div ref={messagesEndRef} />
                </CardContent>
              </Card>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="text-center">
                  <MessageCircle className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">اختر استشارة أو اطرح سؤالاً جديداً</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Question Form */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>اطرح سؤالك</CardTitle>
            <CardDescription>
              اكتب سؤالك حول الأدوية والصحة واحصل على إجابة فورية من نظامنا الذكي
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmitQuestion} className="space-y-4">
              <Textarea
                placeholder="مثال: ما هي الجرعة الآمنة للأسبرين للبالغين؟ أو هل يمكن تناول هذا الدواء مع الطعام؟"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                className="min-h-24"
              />

              <div className="flex gap-2">
                <Button
                  type="submit"
                  disabled={isLoading || !question.trim()}
                  className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 flex-1"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      جاري الإرسال...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      إرسال السؤال
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Info Box */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <p className="text-sm text-blue-900">
              ℹ️ <strong>ملاحظة مهمة:</strong> هذه الاستشارات الذكية لأغراض تعليمية فقط. 
              للحصول على استشارة طبية متخصصة، يرجى التواصل مع الصيدلاني أو الطبيب المختص.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

/**
 * Generate a pharmaceutical answer based on the question
 * This is a placeholder - in production, this would use an LLM API
 */
function generatePharmaceuticalAnswer(question: string): string {
  const lowerQuestion = question.toLowerCase();

  // Aspirin
  if (lowerQuestion.includes("أسبرين") || lowerQuestion.includes("aspirin")) {
    return `الأسبرين (Aspirin):

الجرعة الموصى بها للبالغين:
• للألم والحمى: 325-650 ملغ كل 4-6 ساعات (بحد أقصى 3000 ملغ يومياً)
• للوقاية من الجلطات: 75-325 ملغ يومياً

التعليمات:
✓ تناول مع الطعام أو الحليب لتقليل تهيج المعدة
✓ اشرب كمية كافية من الماء
✓ لا تتجاوز الجرعة الموصى بها

التحذيرات:
⚠️ قد يسبب حساسية لدى بعض الأشخاص
⚠️ تجنب إذا كان لديك قرحة معدية
⚠️ استشر الطبيب إذا كنت حاملاً أو مرضعة`;
  }

  // Generic answer
  return `شكراً على سؤالك الطبي. 

للحصول على إجابة دقيقة وآمنة:
1. استشر الصيدلاني المختص في الصيدلية
2. أخبره عن جميع الأدوية التي تتناولها
3. اذكر أي حالات صحية لديك

نصائح عامة:
✓ اقرأ النشرة الداخلية للدواء بعناية
✓ احفظ الأدوية في مكان بارد وجاف
✓ لا تشارك أدويتك مع الآخرين
✓ لا تتجاوز الجرعة الموصى بها

إذا شعرت بأي أعراض جانبية، توقف عن تناول الدواء واستشر الطبيب فوراً.`;
}
