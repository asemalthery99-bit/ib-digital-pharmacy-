import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Search, ShoppingCart, Heart } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function Products() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [wishlist, setWishlist] = useState<Set<number>>(new Set());

  const productsQuery = trpc.products.list.useQuery();
  const cartMutation = trpc.cart.update.useMutation();

  // Get unique categories
  const categories = useMemo(() => {
    if (!productsQuery.data) return [];
    const cats = new Set(productsQuery.data.map(p => p.category));
    return Array.from(cats).sort();
  }, [productsQuery.data]);

  // Filter products
  const filteredProducts = useMemo(() => {
    if (!productsQuery.data) return [];

    return productsQuery.data.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === "all" || product.category === selectedCategory;
      const price = Number(product.price);
      const matchesPrice = price >= priceRange[0] && price <= priceRange[1];

      return matchesSearch && matchesCategory && matchesPrice;
    });
  }, [productsQuery.data, searchQuery, selectedCategory, priceRange]);

  const handleAddToCart = async (productId: number, quantity: number = 1) => {
    try {
      // Get current cart
      const currentCart = await trpc.cart.get.useQuery().data;
      const items = (currentCart?.items as any[]) || [];

      // Add or update product in cart
      const existingItem = items.find((item: any) => item.productId === productId);
      if (existingItem) {
        existingItem.quantity += quantity;
      } else {
        items.push({ productId, quantity });
      }

      await cartMutation.mutateAsync({ items });
      toast.success("تمت إضافة المنتج إلى السلة");
    } catch (error) {
      toast.error("فشل إضافة المنتج إلى السلة");
    }
  };

  const toggleWishlist = (productId: number) => {
    const newWishlist = new Set(wishlist);
    if (newWishlist.has(productId)) {
      newWishlist.delete(productId);
    } else {
      newWishlist.add(productId);
    }
    setWishlist(newWishlist);
  };

  if (productsQuery.isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-green-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold mb-2">صيدليتنا</h1>
          <p className="text-green-100">اكتشف مجموعتنا الواسعة من الأدوية والمنتجات الصحية</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar - Filters */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle className="text-lg">البحث والفلترة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Search */}
                <div>
                  <label className="text-sm font-medium mb-2 block">البحث</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="ابحث عن منتج..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Category */}
                <div>
                  <label className="text-sm font-medium mb-2 block">الفئة</label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع الفئات</SelectItem>
                      {categories.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Price Range */}
                <div>
                  <label className="text-sm font-medium mb-2 block">نطاق السعر</label>
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="من"
                        value={priceRange[0]}
                        onChange={(e) => setPriceRange([Number(e.target.value), priceRange[1]])}
                        className="flex-1"
                      />
                      <Input
                        type="number"
                        placeholder="إلى"
                        value={priceRange[1]}
                        onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
                        className="flex-1"
                      />
                    </div>
                    <p className="text-xs text-gray-500">
                      ${priceRange[0]} - ${priceRange[1]}
                    </p>
                  </div>
                </div>

                {/* Results count */}
                <div className="pt-4 border-t">
                  <p className="text-sm text-gray-600">
                    عدد النتائج: <span className="font-bold text-green-600">{filteredProducts.length}</span>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content - Products Grid */}
          <div className="lg:col-span-3">
            {filteredProducts.length === 0 ? (
              <Card className="text-center py-12">
                <CardContent>
                  <p className="text-gray-500 mb-4">لم نجد أي منتجات تطابق البحث</p>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchQuery("");
                      setSelectedCategory("all");
                      setPriceRange([0, 10000]);
                    }}
                  >
                    إعادة تعيين الفلاتر
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map(product => (
                  <Card
                    key={product.id}
                    className="hover:shadow-lg transition-shadow overflow-hidden flex flex-col"
                  >
                    {/* Product Image */}
                    <div className="bg-gradient-to-br from-green-100 to-blue-100 h-48 flex items-center justify-center relative group">
                      {product.image ? (
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="text-center">
                          <div className="w-16 h-16 bg-green-200 rounded-full flex items-center justify-center mx-auto mb-2">
                            <span className="text-2xl">💊</span>
                          </div>
                          <p className="text-gray-500 text-sm">صورة المنتج</p>
                        </div>
                      )}

                      {/* Wishlist Button */}
                      <button
                        onClick={() => toggleWishlist(product.id)}
                        className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md hover:bg-red-50 transition-colors"
                      >
                        <Heart
                          className={`w-5 h-5 ${
                            wishlist.has(product.id)
                              ? "fill-red-500 text-red-500"
                              : "text-gray-400"
                          }`}
                        />
                      </button>

                      {/* Prescription Badge */}
                      {product.requiresPrescription && (
                        <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-semibold">
                          يتطلب وصفة
                        </div>
                      )}
                    </div>

                    {/* Product Info */}
                    <CardHeader className="flex-1">
                      <CardTitle className="text-lg line-clamp-2">{product.name}</CardTitle>
                      <CardDescription className="text-xs text-green-600 font-medium">
                        {product.category}
                      </CardDescription>
                      <p className="text-sm text-gray-600 mt-2 line-clamp-2">
                        {product.description}
                      </p>
                    </CardHeader>

                    {/* Product Footer */}
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-green-600">
                          ${Number(product.price).toFixed(2)}
                        </span>
                        <span className={`text-sm font-medium px-3 py-1 rounded-full ${
                          product.stock > 0
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                        }`}>
                          {product.stock > 0 ? `${product.stock} متاح` : "غير متاح"}
                        </span>
                      </div>

                      <Button
                        onClick={() => handleAddToCart(product.id)}
                        disabled={product.stock === 0}
                        className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
                      >
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        أضف إلى السلة
                      </Button>

                      <Button
                        variant="outline"
                        onClick={() => navigate(`/product/${product.id}`)}
                        className="w-full"
                      >
                        عرض التفاصيل
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
