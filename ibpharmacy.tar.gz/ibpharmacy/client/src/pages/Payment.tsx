import { useEffect, useState } from "react";
import { useParams } from "wouter";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, CardElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, AlertCircle, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || "");

interface PaymentPageProps {
  orderId: string;
}

function PaymentForm({ orderId, amount }: { orderId: number; amount: number }) {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<"idle" | "processing" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");

  const createPaymentIntentMutation = trpc.payment.createIntent.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      toast.error("Stripe not loaded");
      return;
    }

    setIsProcessing(true);
    setPaymentStatus("processing");

    try {
      // Create payment intent
      const { clientSecret } = await createPaymentIntentMutation.mutateAsync({
        orderId,
        amount,
      });

      const cardElement = elements.getElement(CardElement);
      if (!cardElement) {
        throw new Error("Card element not found");
      }

      // Confirm payment
      const { error, paymentIntent } = await stripe!.confirmCardPayment(clientSecret || "", {
        payment_method: {
          card: cardElement,
        },
      });

      if (error) {
        setErrorMessage(error.message || "Payment failed");
        setPaymentStatus("error");
        toast.error(error.message || "Payment failed");
      } else if (paymentIntent?.status === "succeeded") {
        setPaymentStatus("success");
        toast.success("Payment successful!");
        // Redirect to order confirmation after 2 seconds
        setTimeout(() => {
          window.location.href = `/orders/${orderId}`;
        }, 2000);
      } else {
        setErrorMessage("Payment processing failed");
        setPaymentStatus("error");
        toast.error("Payment processing failed");
      }
    } catch (error: any) {
      setErrorMessage(error.message || "An error occurred");
      setPaymentStatus("error");
      toast.error(error.message || "An error occurred");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Card Details</CardTitle>
          <CardDescription>Enter your card information to complete the payment</CardDescription>
        </CardHeader>
        <CardContent>
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: "16px",
                  color: "#424770",
                  "::placeholder": {
                    color: "#aab7c4",
                  },
                },
                invalid: {
                  color: "#fa755a",
                },
              },
            }}
          />
        </CardContent>
      </Card>

      {paymentStatus === "error" && (
        <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg">
          <AlertCircle className="w-5 h-5 text-red-600" />
          <p className="text-red-800">{errorMessage}</p>
        </div>
      )}

      {paymentStatus === "success" && (
        <div className="flex items-center gap-2 p-4 bg-green-50 border border-green-200 rounded-lg">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <p className="text-green-800">Payment successful! Redirecting...</p>
        </div>
      )}

      <div className="flex gap-4">
        <Button
          type="submit"
          disabled={isProcessing || !stripe || paymentStatus === "success"}
          className="flex-1"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            `Pay $${amount.toFixed(2)}`
          )}
        </Button>
      </div>
    </form>
  );
}

export default function Payment() {
  const params = useParams<PaymentPageProps>();
  const orderId = params?.orderId ? parseInt(params.orderId) : 0;

  const orderQuery = trpc.orders.getById.useQuery(
    { id: orderId },
    { enabled: !!orderId }
  );

  if (!orderId) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-red-600">Invalid Order</CardTitle>
          </CardHeader>
          <CardContent>
            <p>No order ID provided. Please try again.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (orderQuery.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (orderQuery.isError || !orderQuery.data) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-red-600">Order Not Found</CardTitle>
          </CardHeader>
          <CardContent>
            <p>The order you're trying to pay for could not be found.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const amount = Number(orderQuery.data.totalAmount);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 py-12 px-4">
      <div className="max-w-md mx-auto">
        <Card className="shadow-lg">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-green-600 text-white rounded-t-lg">
            <CardTitle>Payment</CardTitle>
            <CardDescription className="text-blue-100">
              Order #{orderId}
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Order Total:</span>
                <span className="font-bold text-lg">${amount.toFixed(2)}</span>
              </div>
              <p className="text-sm text-gray-500">
                {orderQuery.data.items?.length || 0} item(s)
              </p>
            </div>

            <Elements stripe={stripePromise}>
              <PaymentForm orderId={orderId} amount={amount} />
            </Elements>
          </CardContent>
        </Card>

        <p className="text-center text-sm text-gray-500 mt-4">
          Your payment is secure and encrypted
        </p>
      </div>
    </div>
  );
}
