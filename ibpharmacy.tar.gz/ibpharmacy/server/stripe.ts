import Stripe from 'stripe';
import { ENV } from './_core/env';

// Stripe is optional - only initialize if secret key is provided
let stripe: Stripe | null = null;

if (ENV.stripeSecretKey) {
  stripe = new Stripe(ENV.stripeSecretKey, {
    apiVersion: '2026-02-25.clover',
  });
} else {
  console.warn('[Stripe] STRIPE_SECRET_KEY is not configured - payment features will be disabled');
}

export { stripe };

/**
 * Create a payment intent for an order
 */
export async function createPaymentIntent(
  amount: number,
  orderId: number,
  customerEmail?: string
) {
  if (!stripe) {
    throw new Error('Stripe is not configured. Please add STRIPE_SECRET_KEY to your environment variables.');
  }
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // Convert to cents
      currency: 'usd',
      metadata: {
        orderId: orderId.toString(),
      },
      receipt_email: customerEmail,
    });

    return paymentIntent;
  } catch (error) {
    console.error('[Stripe] Error creating payment intent:', error);
    throw error;
  }
}

/**
 * Retrieve a payment intent
 */
export async function getPaymentIntent(paymentIntentId: string) {
  if (!stripe) {
    throw new Error('Stripe is not configured');
  }
  try {
    return await stripe.paymentIntents.retrieve(paymentIntentId);
  } catch (error) {
    console.error('[Stripe] Error retrieving payment intent:', error);
    throw error;
  }
}

/**
 * Confirm a payment intent
 */
export async function confirmPaymentIntent(
  paymentIntentId: string,
  paymentMethodId: string
) {
  if (!stripe) {
    throw new Error('Stripe is not configured');
  }
  try {
    return await stripe.paymentIntents.confirm(paymentIntentId, {
      payment_method: paymentMethodId,
    });
  } catch (error) {
    console.error('[Stripe] Error confirming payment intent:', error);
    throw error;
  }
}

/**
 * Cancel a payment intent
 */
export async function cancelPaymentIntent(paymentIntentId: string) {
  if (!stripe) {
    throw new Error('Stripe is not configured');
  }
  try {
    return await stripe.paymentIntents.cancel(paymentIntentId);
  } catch (error) {
    console.error('[Stripe] Error canceling payment intent:', error);
    throw error;
  }
}

/**
 * Verify webhook signature
 */
export function verifyWebhookSignature(
  body: string,
  signature: string
): Stripe.Event | null {
  if (!stripe) {
    console.warn('[Stripe] Stripe is not configured');
    return null;
  }
  try {
    if (!ENV.stripeWebhookSecret) {
      console.warn('[Stripe] Webhook secret not configured');
      return null;
    }

    return stripe.webhooks.constructEvent(
      body,
      signature,
      ENV.stripeWebhookSecret
    );
  } catch (error) {
    console.error('[Stripe] Error verifying webhook signature:', error);
    return null;
  }
}
